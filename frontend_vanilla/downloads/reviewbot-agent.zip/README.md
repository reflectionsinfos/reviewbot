# ReviewBot Local Agent

Lightweight local agent for autonomous AI code reviews. Scans your codebase, uploads file metadata and content to the ReviewBot server, and streams back AI-generated RAG (Red / Amber / Green) findings.

---

## Installation

```bash
# From source (run once)
pip install -e .
```

---

## Quick Start

### Step 1 — Login

```bash
reviewbot login --server http://localhost:8000
```

You will be prompted for your **email** and **password**. On success, the JWT token is saved locally — you stay logged in for 8 hours before needing to log in again.

#### PowerShell note
`reviewbot` is a Python CLI entry-point. Run it directly — no special syntax needed:

```powershell
reviewbot login --server http://localhost:8000
```

If you get `'reviewbot' is not recognized`, make sure the Python Scripts folder is on your PATH (usually `%APPDATA%\Python\Python3xx\Scripts` or the Scripts folder of your virtual environment).

---

### Step 2 — Find your Project ID and Checklist ID

**Option A — PowerShell (using saved token)**

```powershell
$config = Get-Content "$env:USERPROFILE\.reviewbot\config.json" | ConvertFrom-Json
$token  = $config.api_key

# List projects
Invoke-RestMethod http://localhost:8000/api/projects/ `
  -Headers @{Authorization="Bearer $token"}

# List checklists for a project (replace 5 with your project ID)
Invoke-RestMethod http://localhost:8000/api/projects/5/checklists `
  -Headers @{Authorization="Bearer $token"}
```

**Option B — curl.exe (PowerShell)**

PowerShell's built-in `curl` is an alias for `Invoke-WebRequest` and uses different syntax. Use `curl.exe` to get real curl behaviour:

```powershell
$token = (Get-Content "$env:USERPROFILE\.reviewbot\config.json" | ConvertFrom-Json).api_key

curl.exe http://localhost:8000/api/projects/ -H "Authorization: Bearer $token"
curl.exe http://localhost:8000/api/projects/5/checklists -H "Authorization: Bearer $token"
```

**Option C — Swagger UI**
Open [http://localhost:8000/docs](http://localhost:8000/docs), click **Authorize**, paste your token, then call `GET /api/projects/`.

**Option D — History UI**
Open [http://localhost:8000/history](http://localhost:8000/history) and log in — project and checklist names are visible in the table.

---

### Step 3 — Run a Review

**bash / Git Bash:**
```bash
reviewbot review \
  --project-id 5 \
  --checklist-id 11 \
  --source-path C:/projects/my-service \
  --output C:/tmp/review-report.md
```

**PowerShell (backtick line continuation):**
```powershell
reviewbot review `
  --project-id 5 `
  --checklist-id 11 `
  --source-path C:/projects/my-service `
  --output C:/tmp/review-report.md
```

> **Tip:** Always use an absolute path for `--output` to avoid confusion about where the file lands.

What happens internally:
1. **Scan** — walks the local directory, collects file paths, sizes, hashes (~2 s for 200 files)
2. **Upload metadata** — sends the file index to the server; server creates a queued job
3. **Upload file content** — sends file contents (≤ 1 MB each) so the LLM can read your code
4. **Start analysis** — triggers the server-side AI pipeline
5. **Poll & display** — waits for completion, prints RAG summary, saves Markdown report

---

## All Commands

### `reviewbot login`

Authenticate with the ReviewBot server. Saves a JWT token locally.

```
reviewbot login [OPTIONS]

Options:
  -s, --server TEXT   ReviewBot server URL  [default: http://localhost:8000]
  -e, --email TEXT    Your ReviewBot account email  (prompted if omitted)
  -p, --password TEXT Your password  (prompted securely if omitted)
```

Example:
```bash
reviewbot login --server http://localhost:8000
```

---

### `reviewbot review`

Scan a local directory and run an autonomous AI code review against a checklist.

```
reviewbot review [OPTIONS]

Options:
  -p, --project-id INTEGER    Project ID  (required)
  -c, --checklist-id INTEGER  Checklist ID  (required)
  -S, --source-path PATH      Local path to the source code directory  (required)
  -o, --output PATH           Output file for the Markdown report  [default: review-report.md]
  -w, --watch                 Watch for changes and re-run  (not yet implemented)
```

Example:
```bash
reviewbot review \
  --project-id 5 \
  --checklist-id 11 \
  --source-path C:/projects/hatch-pay/backend/payment-service \
  --output C:/tmp/report.md
```

---

### `reviewbot status`

Show current login state and server URL.

```bash
reviewbot status
```

Sample output:
```
╭─────────────────────────╮
│ ReviewBot Agent Status  │
╰─────────────────────────╯
Server: http://localhost:8000
Logged in: Yes
Debug mode: Off
```

---

### `reviewbot logout`

Clear saved credentials from disk.

```bash
reviewbot logout
```

---

## Where Credentials Are Stored

All configuration is saved in a single JSON file:

| OS | Path |
|----|------|
| Windows | `C:\Users\<username>\.reviewbot\config.json` |
| macOS / Linux | `~/.reviewbot/config.json` |

Contents:
```json
{
  "server": "http://localhost:8000",
  "api_key": "<JWT token>",
  "email": "you@example.com"
}
```

**Read the token in PowerShell:**
```powershell
$config = Get-Content "$env:USERPROFILE\.reviewbot\config.json" | ConvertFrom-Json
$token  = $config.api_key
$token   # prints the token
```

**Read the token in bash / WSL:**
```bash
python -c "import json,os; c=json.load(open(os.path.expanduser('~/.reviewbot/config.json'))); print(c['api_key'])"
```

The token is a standard JWT. It expires after **8 hours** — run `reviewbot login` again when it does.
A `401 Unauthorized` error from the server always means the token has expired.

---

## What the Agent Sends to the Server

| Data | When | Notes |
|------|------|-------|
| File metadata | Upload step | Relative paths, sizes, hashes, line counts, detected language |
| File content | Content upload step | UTF-8 text, files ≤ 1 MB only |
| Source path | Upload step | Absolute path of the scanned directory (shown in History UI) |
| Agent info | Upload step | Hostname, local IP, OS platform/version, OS username, agent version |

File content is held **in server memory only** for the duration of the job. It is not written to disk or persisted in the database.

---

## Configuration via Environment Variables

Instead of the config file you can use environment variables:

**PowerShell:**
```powershell
$env:REVIEWBOT_SERVER  = "http://localhost:8000"
$env:REVIEWBOT_API_KEY = "<your-token>"
```

**bash:**
```bash
export REVIEWBOT_SERVER=http://localhost:8000
export REVIEWBOT_API_KEY=<your-token>
```

---

## Supported File Types

| Extension | Language |
|-----------|----------|
| `.py` | Python |
| `.js` `.jsx` | JavaScript |
| `.ts` `.tsx` | TypeScript |
| `.java` | Java |
| `.go` | Go |
| `.rs` | Rust |
| `.cs` | C# |
| `.cpp` `.c` `.h` | C/C++ |
| `.rb` | Ruby |
| `.php` | PHP |
| `.swift` `.kt` `.scala` | Swift / Kotlin / Scala |
| `.sql` | SQL |
| `.yaml` `.yml` `.json` `.xml` | Config |
| `.md` `.sh` `.bash` | Docs / Shell |

**Skipped directories:** `node_modules`, `__pycache__`, `.git`, `venv`, `.venv`, `dist`, `build`, `target`, `bin`, `.egg-info`

Files larger than **1 MB** are included in the metadata scan but their content is not sent to the LLM.

---

## Troubleshooting

| Error | Cause | Fix |
|-------|-------|-----|
| `401 Unauthorized` | Token expired | Run `reviewbot login` again |
| `404 Project not found` | Wrong `--project-id` | List projects via API and check IDs |
| `400 Checklist has no items` | Checklist is empty | Upload checklist items via the History UI first |
| `reviewbot` not recognized | CLI not on PATH | Activate virtualenv or add Python Scripts to PATH |
| `Connection error` | Server not running | Start server: `docker-compose up` |
| Report saved to wrong folder | Relative `--output` path | Use absolute path: `--output C:/tmp/report.md` |
| `curl` fails with `Cannot bind parameter` | PowerShell alias conflict | Use `curl.exe` (with `.exe`) or `Invoke-RestMethod` |
