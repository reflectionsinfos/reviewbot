# ReviewBot CLI Agent

Lightweight Python CLI that runs autonomous AI code reviews from your terminal or CI/CD pipeline. Scans a local directory, uploads file metadata and content to the ReviewBot server, and streams back AI-generated RAG (Red / Amber / Green) findings with a compliance score and Markdown report.

---

## Production Server

| | |
|---|---|
| **URL** | `https://reviewbot-web-128263129038.us-central1.run.app` |
| **API Docs** | `https://reviewbot-web-128263129038.us-central1.run.app/docs` |
| **UI** | `https://reviewbot-web-128263129038.us-central1.run.app/ui` |

---

## Installation

```bash
# From source
pip install -e .
```

Or install the distributed package:

```bash
pip install reviewbot-agent
```

---

## Quick Start

### Step 1 — Login

```bash
reviewbot login --server https://reviewbot-web-128263129038.us-central1.run.app
```

You will be prompted for your **email** and **password**. No prior authentication is needed — this command IS the authentication step. On success, the JWT token is saved locally and you stay logged in for **8 hours**.

> The login endpoint (`POST /api/auth/login`) is public — no token is required to call it.

#### PowerShell

```powershell
reviewbot login --server https://reviewbot-web-128263129038.us-central1.run.app
```

If `reviewbot` is not recognised, add the Python Scripts folder to your PATH (`%APPDATA%\Python\Python3xx\Scripts` or the Scripts folder of your virtualenv).

---

### Step 2 — Find your Project ID and Checklist ID

The easiest way is the **AI Review UI** — select your project and checklist from the dropdowns; the CLI commands are pre-filled automatically.

Alternatively:

**PowerShell:**
```powershell
$config = Get-Content "$env:USERPROFILE\.reviewbot\config.json" | ConvertFrom-Json
$token  = $config.api_key

# List projects
Invoke-RestMethod https://reviewbot-web-128263129038.us-central1.run.app/api/projects/ `
  -Headers @{Authorization="Bearer $token"}

# List checklists for project 5
Invoke-RestMethod https://reviewbot-web-128263129038.us-central1.run.app/api/projects/5/checklists `
  -Headers @{Authorization="Bearer $token"}
```

**bash / curl:**
```bash
token=$(python -c "import json,os; print(json.load(open(os.path.expanduser('~/.reviewbot/config.json')))['api_key'])")

curl https://reviewbot-web-128263129038.us-central1.run.app/api/projects/ \
  -H "Authorization: Bearer $token"
```

**Swagger UI:** Open `/docs`, click Authorize, paste your token, then call `GET /api/projects/`.

---

### Step 3 — Run a Review

**bash / Git Bash:**
```bash
reviewbot review \
  --project-id 5 \
  --checklist-id 11 \
  --source-path ./my-project \
  --output ./review-report.md
```

**PowerShell:**
```powershell
reviewbot review `
  --project-id 5 `
  --checklist-id 11 `
  --source-path ./my-project `
  --output ./review-report.md
```

> Always use an absolute path for `--output` to avoid confusion about where the file lands.

**What happens internally:**
1. **Scan** — walks the local directory, collects file paths, sizes, hashes (~2 s for 200 files)
2. **Upload metadata** — sends the file index to the server; server creates a queued job
3. **Upload file content** — sends UTF-8 file contents (≤ 1 MB each) so the LLM can read your code
4. **Start analysis** — triggers the server-side AI pipeline
5. **Poll & display** — waits for completion, prints RAG summary, saves Markdown report

---

## All Commands

### `reviewbot login`

Authenticate with the ReviewBot server. Saves a JWT token locally.

```
reviewbot login [OPTIONS]

Options:
  -s, --server TEXT   ReviewBot server URL  [default: http://localhost:8000]
  -e, --email TEXT    Your ReviewBot account email  (prompted if omitted)
  -p, --password TEXT Your password  (prompted securely if omitted)
```

No prior authentication needed — this is the entry point for all other commands.

---

### `reviewbot review`

Scan a local directory and run an autonomous AI code review against a checklist.

```
reviewbot review [OPTIONS]

Options:
  -p, --project-id INTEGER    Project ID  (required)
  -c, --checklist-id INTEGER  Checklist ID  (required)
  -S, --source-path PATH      Local path to the source code directory  (required)
  -o, --output PATH           Output file for the Markdown report  [default: review-report.md]
  -w, --watch                 Watch for changes and re-run  (not yet implemented)
```

---

### `reviewbot status`

Show current login state and server URL.

```bash
reviewbot status
```

Sample output:
```
╭─────────────────────────╮
│ ReviewBot Agent Status  │
╰─────────────────────────╯
Server: https://reviewbot-web-128263129038.us-central1.run.app
Logged in: Yes
Debug mode: Off
```

---

### `reviewbot logout`

Clear saved credentials from disk.

```bash
reviewbot logout
```

---

## Credentials Storage

All configuration is saved in a single JSON file:

| OS | Path |
|----|------|
| Windows | `C:\Users\<username>\.reviewbot\config.json` |
| macOS / Linux | `~/.reviewbot/config.json` |

```json
{
  "server": "https://reviewbot-web-128263129038.us-central1.run.app",
  "api_key": "<JWT token>",
  "email": "you@example.com"
}
```

The token expires after **8 hours**. A `401 Unauthorized` response from the server means the token has expired — run `reviewbot login` again.

**Read the token in PowerShell:**
```powershell
$config = Get-Content "$env:USERPROFILE\.reviewbot\config.json" | ConvertFrom-Json
$token  = $config.api_key
```

**Read the token in bash:**
```bash
python -c "import json,os; c=json.load(open(os.path.expanduser('~/.reviewbot/config.json'))); print(c['api_key'])"
```

---

## Environment Variables

Instead of the config file you can use environment variables:

**PowerShell:**
```powershell
$env:REVIEWBOT_SERVER  = "https://reviewbot-web-128263129038.us-central1.run.app"
$env:REVIEWBOT_API_KEY = "<your-token>"
```

**bash:**
```bash
export REVIEWBOT_SERVER=https://reviewbot-web-128263129038.us-central1.run.app
export REVIEWBOT_API_KEY=<your-token>
```

---

## What the Agent Sends to the Server

| Data | When | Notes |
|------|------|-------|
| File metadata | Upload step | Relative paths, sizes, SHA-256 hashes, line counts, detected language |
| File content | Content upload step | UTF-8 text, files ≤ 1 MB only |
| Source path | Upload step | Absolute path of the scanned directory |
| Agent info | Upload step | Hostname, local IP, OS platform/version, OS username, agent version |

File content is held **in server memory only** for the duration of the job. It is not written to disk or persisted in the database.

---

## Supported File Types

| Extension | Language |
|-----------|----------|
| `.py` | Python |
| `.js` `.jsx` | JavaScript |
| `.ts` `.tsx` | TypeScript |
| `.java` | Java |
| `.go` | Go |
| `.rs` | Rust |
| `.cs` | C# |
| `.cpp` `.c` `.h` | C/C++ |
| `.rb` | Ruby |
| `.php` | PHP |
| `.swift` `.kt` `.scala` | Swift / Kotlin / Scala |
| `.sql` | SQL |
| `.yaml` `.yml` `.json` `.xml` | Config |
| `.md` `.sh` `.bash` | Docs / Shell |

**Skipped directories:** `node_modules`, `__pycache__`, `.git`, `venv`, `.venv`, `dist`, `build`, `target`, `bin`, `.egg-info`

Files larger than **1 MB** are included in the metadata scan but their content is not sent to the LLM.

---

## Troubleshooting

| Error | Cause | Fix |
|-------|-------|-----|
| `401 Unauthorized` | Token expired | Run `reviewbot login` again |
| `404 Project not found` | Wrong `--project-id` | Check project IDs in the UI or API |
| `400 Checklist has no items` | Checklist is empty | Add items via the Projects UI |
| `reviewbot` not recognised | CLI not on PATH | Activate virtualenv or add Python Scripts to PATH |
| `Connection error` | Server not reachable | Check the server URL; verify network access |
| Report saved to wrong folder | Relative `--output` path | Use an absolute path: `--output C:/tmp/report.md` |
| `curl` fails in PowerShell | Alias conflict | Use `curl.exe` or `Invoke-RestMethod` |

---

## License

Copyright (c) 2024 Reflections Info Systems. All rights reserved.
