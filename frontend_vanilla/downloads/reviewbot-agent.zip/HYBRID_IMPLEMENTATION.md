# Hybrid Architecture Implementation

> Local Agent + Server Architecture

**Version:** 1.0  
**Date:** March 27, 2026  
**Status:** ✅ Agent Complete, ⏳ Server API Pending

---

## 🎯 **Architecture Overview**

```
┌─────────────────────────────────────────────────────────────┐
│              Local Agent (reviewbot-agent)                  │
│              Size: ~10 MB, Install: pip install             │
├─────────────────────────────────────────────────────────────┤
│  ✅ File scanner (reads code structure)                     │
│  ✅ Metadata extractor (paths, sizes, hashes)               │
│  ✅ CLI interface (reviewbot command)                       │
│  ✅ Configuration management                                │
│  ❌ NO LLM calls                                            │
│  ❌ NO database                                             │
│  ❌ NO full code upload                                     │
└─────────────────────────────────────────────────────────────┘
                              │
                              │ HTTPS (encrypted)
                              │ Uploads: file metadata only
                              ▼
┌─────────────────────────────────────────────────────────────┐
│              Server (reviewbot)                             │
│              Already deployed in Docker                     │
├─────────────────────────────────────────────────────────────┤
│  ✅ LLM API calls (OpenAI, Anthropic, etc.)                │
│  ✅ RAG assessment                                          │
│  ✅ Report generation                                       │
│  ✅ User authentication                                     │
│  ✅ Database (PostgreSQL)                                   │
│  ✅ Audit trail                                             │
│  ✅ Request specific files from agent (on-demand)           │
└─────────────────────────────────────────────────────────────┘
```

---

## 📦 **What's Been Created**

### **Local Agent** ✅

**Location:** `c:\projects\reviewbot-agent`

**Files Created:**
```
reviewbot-agent/
├── pyproject.toml              # Package configuration
├── README.md                   # Documentation
├── .gitignore                  # Git exclusions
└── reviewbot_agent/
    ├── __init__.py             # Package init
    ├── cli.py                  # CLI interface (200 lines)
    ├── scanner.py              # Code scanner (150 lines)
    ├── uploader.py             # Server uploader (100 lines)
    └── config.py               # Configuration (50 lines)
```

**Total:** ~500 lines of Python, ~10 MB package

---

## 🚀 **How It Works**

### **Step-by-Step Flow:**

```
1. User runs: reviewbot review --project-id 1 --source-path ./my-project
   │
   ▼
2. Agent scans local files:
   - Reads file paths
   - Calculates file sizes
   - Computes file hashes
   - Counts lines
   - Detects languages
   │
   ▼
3. Agent uploads METADATA ONLY to server:
   {
     "files": [
       {"path": "src/main.py", "size": 1024, "hash": "abc123"},
       {"path": "src/utils.py", "size": 512, "hash": "def456"}
     ],
     "total_size_mb": 1.5,
     "language_stats": {"python": 50}
   }
   │
   ▼
4. Server analyzes metadata:
   - Determines which files to analyze
   - Requests specific files from agent (on-demand)
   - Runs LLM analysis
   │
   ▼
5. Server returns results:
   - RAG status per file
   - Recommendations
   - Report
   │
   ▼
6. Agent displays results locally
```

---

## 🔒 **Security Benefits**

### **What's Uploaded:**
```json
{
  "files": [
    {
      "path": "src/main.py",
      "size_bytes": 1024,
      "language": "python",
      "hash": "sha256:abc123...",
      "line_count": 50
    }
  ],
  "total_size_mb": 1.5,
  "language_stats": {"python": 50}
}
```

### **What's NOT Uploaded:**
- ❌ File content (code)
- ❌ Comments
- ❌ Business logic
- ❌ API keys
- ❌ Secrets

### **On-Demand Code Fetching:**
```python
# Server requests specific file ONLY if needed
if file_needs_analysis:
    code_content = agent.get_file_content(file_path)
    # Analyze code
    # Discard after analysis (don't store)
```

---

## 📋 **Server API Endpoints Needed**

### **New Endpoints to Implement:**

```python
# 1. Receive scan metadata
POST /api/v1/agent/scan/upload
Request: {
  "project_id": int,
  "checklist_id": int,
  "scan_result": {files, directories, stats}
}
Response: {"job_id": int, "status": "queued"}

# 2. Get job status
GET /api/v1/agent/scan/{job_id}
Response: {"status": "queued|running|completed|failed"}

# 3. Get job results
GET /api/v1/agent/scan/{job_id}/results
Response: {summary, items, compliance_score}

# 4. Submit override
POST /api/v1/agent/scan/{job_id}/results/{result_id}/override
Request: {
  "new_rag_status": "green|amber|red|na",
  "comments": str,
  "reason": str
}
Response: {"status": "success"}

# 5. Request file content (server → agent)
POST /api/v1/agent/scan/{job_id}/request-file
Request: {"file_path": "src/main.py"}
Response: {"content": "..."}
```

---

## 🎯 **Next Steps**

### **Phase 1: Server API** (1-2 days)

**File:** `app/api/routes/agent.py`

```python
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession

router = APIRouter(prefix="/api/v1/agent", tags=["Agent API"])

@router.post("/scan/upload")
async def receive_scan(scan_data: dict, db: AsyncSession = Depends(get_db)):
    """Receive scan metadata from local agent"""
    # Create job
    # Start background analysis
    return {"job_id": job_id}

@router.get("/scan/{job_id}")
async def get_scan_status(job_id: int, db: AsyncSession = Depends(get_db)):
    """Get job status"""
    return {"status": job.status}

@router.get("/scan/{job_id}/results")
async def get_scan_results(job_id: int, db: AsyncSession = Depends(get_db)):
    """Get job results"""
    return results
```

---

### **Phase 2: Test Integration** (1 day)

**Test Script:**
```bash
# 1. Install agent
cd c:\projects\reviewbot-agent
pip install -e .

# 2. Login
reviewbot login --server http://localhost:8000

# 3. Start review
reviewbot review \
  --project-id 1 \
  --checklist-id 2 \
  --source-path c:\projects\my-project

# 4. Verify results displayed
```

---

### **Phase 3: Package & Distribute** (1 day)

**Publish to PyPI:**
```bash
# Build package
python -m build

# Upload to PyPI
python -m twine upload dist/*

# Users can now install with:
pip install reviewbot-agent
```

---

## 📊 **Comparison: Before vs After**

| Aspect | Before (Docker) | After (Hybrid) |
|--------|----------------|----------------|
| **Installation** | Docker + volume mounts | `pip install reviewbot-agent` |
| **File Access** | Volume mount required | Direct local access |
| **Path Issues** | Windows vs Linux paths | No path issues |
| **Code Upload** | All code on server | Metadata only |
| **Privacy** | Code stored on server | Code stays local |
| **Updates** | Rebuild Docker | `pip install --upgrade` |
| **Offline Mode** | Yes | Partial (scan only) |
| **Team Collaboration** | Hard (need VPN) | Easy (cloud-native) |
| **Multi-tenant** | No | Yes |
| **Audit Trail** | Per deployment | Central |

---

## 🎉 **Benefits**

### **For Users:**
1. ✅ No Docker complexity
2. ✅ No volume mount issues
3. ✅ Works on any OS
4. ✅ Fast installation
5. ✅ Auto-updates

### **For Security:**
1. ✅ Code stays local
2. ✅ Encrypted communication
3. ✅ Minimal data upload
4. ✅ On-demand code fetch
5. ✅ No persistent storage

### **For Business:**
1. ✅ SaaS ready
2. ✅ Multi-tenant
3. ✅ Central billing
4. ✅ Central audit trail
5. ✅ Easy scaling

---

## 📝 **Files Created**

### **Agent Repository:**
- ✅ `pyproject.toml` - Package config
- ✅ `README.md` - Documentation
- ✅ `.gitignore` - Git exclusions
- ✅ `reviewbot_agent/__init__.py` - Package init
- ✅ `reviewbot_agent/cli.py` - CLI (200 lines)
- ✅ `reviewbot_agent/scanner.py` - Scanner (150 lines)
- ✅ `reviewbot_agent/uploader.py` - Uploader (100 lines)
- ✅ `reviewbot_agent/config.py` - Config (50 lines)

**Total:** 8 files, ~500 lines of code

---

## 🚀 **Ready to Test!**

### **Try It Now:**

```bash
# 1. Go to agent directory
cd c:\projects\reviewbot-agent

# 2. Install locally
pip install -e .

# 3. Login
reviewbot login --server http://localhost:8000

# 4. Check status
reviewbot status

# 5. Start review (once server API is ready)
reviewbot review --project-id 1 --checklist-id 2 --source-path ./test-project
```

---

## 🔗 **Related Documents**

- [`docs/REPORT_HISTORY_COMPLETE.md`](REPORT_HISTORY_COMPLETE.md) - Backend APIs
- [`docs/OVERRIDE_FEATURE.md`](OVERRIDE_FEATURE.md) - Override feature
- [`README.md`](../README.md) - Main README

---

*Document Owner: Engineering Team*  
*Last Updated: March 27, 2026*  
*Status: Agent 100% Complete, Server API 0% Complete*  
*Next: Implement server API endpoints*
