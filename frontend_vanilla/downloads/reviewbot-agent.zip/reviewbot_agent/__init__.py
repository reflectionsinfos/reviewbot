"""
ReviewBot Local Agent
Lightweight scanner for autonomous code reviews
"""
__version__ = "0.1.0"
__author__ = "ReviewBot Team"
