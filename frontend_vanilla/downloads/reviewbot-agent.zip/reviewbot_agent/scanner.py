"""
Code Scanner - Scans local directory and extracts code structure
"""
import os
import json
from pathlib import Path
from typing import Dict, List, Any
import hashlib

# File extensions to scan
CODE_EXTENSIONS = {
    '.py': 'python',
    '.js': 'javascript',
    '.ts': 'typescript',
    '.jsx': 'javascript',
    '.tsx': 'typescript',
    '.java': 'java',
    '.go': 'go',
    '.rs': 'rust',
    '.rb': 'ruby',
    '.php': 'php',
    '.cs': 'csharp',
    '.cpp': 'cpp',
    '.c': 'c',
    '.h': 'cpp',
    '.hpp': 'cpp',
    '.swift': 'swift',
    '.kt': 'kotlin',
    '.scala': 'scala',
    '.sql': 'sql',
    '.yaml': 'yaml',
    '.yml': 'yaml',
    '.json': 'json',
    '.xml': 'xml',
    '.md': 'markdown',
    '.sh': 'shell',
    '.bash': 'shell',
}

# Directories to skip
SKIP_DIRS = {
    'node_modules',
    '__pycache__',
    '.git',
    '.svn',
    '.hg',
    '.idea',
    '.vscode',
    'venv',
    'env',
    '.venv',
    'dist',
    'build',
    'target',
    'out',
    'bin',
    'obj',
    '.egg-info',
    '.tox',
    'coverage',
    'htmlcov',
}

# Files to skip
SKIP_FILES = {
    '.DS_Store',
    'Thumbs.db',
    '.gitignore',
    '.dockerignore',
    'package-lock.json',
    'yarn.lock',
    'poetry.lock',
    'Pipfile.lock',
}


def scan_directory(base_path: str) -> Dict[str, Any]:
    """
    Scan directory and extract code structure
    
    Returns:
        Dictionary with:
        - files: List of file metadata
        - directories: List of directories
        - total_size_mb: Total size in MB
        - language_stats: Count by language
    """
    base = Path(base_path).resolve()
    
    if not base.exists():
        raise FileNotFoundError(f"Path does not exist: {base}")
    
    result = {
        'base_path': str(base),
        'files': [],
        'directories': set(),
        'total_size_bytes': 0,
        'language_stats': {},
    }
    
    # Walk directory
    for root, dirs, files in os.walk(base):
        # Skip ignored directories
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
        
        # Record directory
        rel_dir = os.path.relpath(root, base)
        if rel_dir != '.':
            result['directories'].add(rel_dir)
        
        # Process files
        for file in files:
            if file in SKIP_FILES:
                continue
            
            file_path = os.path.join(root, file)
            rel_path = os.path.relpath(file_path, base)
            
            # Get file info
            try:
                stat = os.stat(file_path)
                ext = os.path.splitext(file)[1].lower()
                language = CODE_EXTENSIONS.get(ext, 'unknown')
                
                file_info = {
                    'path': rel_path,
                    'size_bytes': stat.st_size,
                    'language': language,
                    'extension': ext,
                    'hash': calculate_file_hash(file_path),
                    'line_count': count_lines(file_path),
                }
                
                result['files'].append(file_info)
                result['total_size_bytes'] += stat.st_size
                
                # Update language stats
                result['language_stats'][language] = \
                    result['language_stats'].get(language, 0) + 1
                    
            except (PermissionError, OSError) as e:
                # Skip files we can't read
                continue
    
    # Convert set to list for JSON serialization
    result['directories'] = list(result['directories'])
    result['total_size_mb'] = result['total_size_bytes'] / (1024 * 1024)
    
    return result


def calculate_file_hash(file_path: str) -> str:
    """Calculate SHA256 hash of file"""
    sha256 = hashlib.sha256()
    try:
        with open(file_path, 'rb') as f:
            for chunk in iter(lambda: f.read(8192), b''):
                sha256.update(chunk)
        return sha256.hexdigest()
    except (PermissionError, OSError):
        return ''


def count_lines(file_path: str) -> int:
    """Count lines in file"""
    try:
        with open(file_path, 'rb') as f:
            return sum(1 for _ in f)
    except (PermissionError, OSError):
        return 0


def get_file_content(file_path: str, max_size_mb: float = 1.0) -> str:
    """
    Get file content (with size limit)
    
    Args:
        file_path: Path to file
        max_size_mb: Maximum file size in MB
    
    Returns:
        File content or empty string if too large
    """
    try:
        size_mb = os.path.getsize(file_path) / (1024 * 1024)
        if size_mb > max_size_mb:
            return ''  # Skip large files
        
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            return f.read()
    except (PermissionError, OSError, UnicodeDecodeError):
        return ''
