"""
Server Uploader - Uploads scan results to ReviewBot server
"""
import httpx
import time
import os
from typing import Dict, Any, Optional, List
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
import base64
import json


class ServerClient:
    """HTTP client for ReviewBot server"""
    
    def __init__(self, base_url: str, api_key: str):
        self.base_url = base_url.rstrip('/')
        self.api_key = api_key
        self.client = httpx.Client(
            base_url=self.base_url,
            headers={
                'Authorization': f'Bearer {api_key}',
                'Content-Type': 'application/json',
            },
            timeout=300.0,  # 5 minute timeout for uploads
        )
    
    def upload_scan(self, scan_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Upload scan results to server
        
        Args:
            scan_data: Scan result from scanner.scan_directory()
        
        Returns:
            Job information with job_id
        """
        response = self.client.post(
            '/api/v1/agent/scan/upload',
            json=scan_data,
        )
        response.raise_for_status()
        return response.json()
    
    def get_job_status(self, job_id: int) -> Dict[str, Any]:
        """Get job status"""
        response = self.client.get(f'/api/v1/agent/scan/{job_id}')
        response.raise_for_status()
        return response.json()
    
    def get_job_results(self, job_id: int) -> Dict[str, Any]:
        """Get job results"""
        response = self.client.get(f'/api/v1/agent/scan/{job_id}/results')
        response.raise_for_status()
        return response.json()
    
    def start_job(self, job_id: int) -> Dict[str, Any]:
        """Signal the server to begin analysis (call after uploading all files)"""
        response = self.client.post(f'/api/v1/agent/scan/{job_id}/start')
        response.raise_for_status()
        return response.json()

    def get_file_requests(self, job_id: int) -> List[Dict[str, str]]:
        """Get list of file content requests from server"""
        response = self.client.get(f'/api/v1/agent/scan/{job_id}/file-requests')
        response.raise_for_status()
        return response.json().get('pending_requests', [])

    def upload_file_content(self, job_id: int, file_path: str, content: str) -> Dict[str, Any]:
        """Upload content of a requested file to server"""
        response = self.client.post(
            f'/api/v1/agent/scan/{job_id}/file-content',
            json={'file_path': file_path, 'content': content},
        )
        response.raise_for_status()
        return response.json()

    def submit_override(self, job_id: int, result_id: int,
                       new_rag_status: str, comments: str,
                       reason: Optional[str] = None) -> Dict[str, Any]:
        """Submit override for a result"""
        response = self.client.post(
            f'/api/v1/agent/scan/{job_id}/results/{result_id}/override',
            json={
                'new_rag_status': new_rag_status,
                'comments': comments,
                'reason': reason,
            }
        )
        response.raise_for_status()
        return response.json()


def _collect_agent_info() -> Dict[str, Any]:
    """Collect local machine metadata for audit/security purposes."""
    import platform
    import socket
    info = {
        "agent_version": "0.1.0",
        "hostname": None,
        "ip_address": None,
        "os_platform": platform.system(),
        "os_version": platform.version(),
        "username": None,
    }
    try:
        info["hostname"] = socket.gethostname()
    except Exception:
        pass
    try:
        info["ip_address"] = socket.gethostbyname(socket.gethostname())
    except Exception:
        pass
    try:
        info["username"] = os.getlogin()
    except Exception:
        pass
    return info


def upload_all_files(server_url: str, api_key: str, job_id: int,
                    source_path: str, scan_result: Dict[str, Any],
                    progress_cb=None) -> int:
    """
    Upload all scanned file contents to the server before analysis starts.
    Returns the number of files successfully uploaded.
    """
    client = ServerClient(server_url, api_key)
    uploaded = 0
    files = scan_result.get('files', [])

    for file_info in files:
        rel_path = file_info['path']
        abs_path = os.path.join(source_path, rel_path)
        if not os.path.isfile(abs_path):
            continue
        size_mb = file_info.get('size_bytes', 0) / (1024 * 1024)
        if size_mb > 1.0:
            continue  # skip files > 1 MB
        try:
            with open(abs_path, 'r', encoding='utf-8', errors='replace') as fh:
                content = fh.read()
            client.upload_file_content(job_id, rel_path, content)
            uploaded += 1
            if progress_cb:
                progress_cb(uploaded, len(files))
        except Exception:
            pass  # skip unreadable files

    return uploaded


def upload_to_server(server_url: str, api_key: str,
                    project_id: int, checklist_id: int,
                    scan_result: Dict[str, Any],
                    source_path: str = "") -> Dict[str, Any]:
    """
    Upload scan result to server and start review
    
    Args:
        server_url: Server URL
        api_key: API key
        project_id: Project ID
        checklist_id: Checklist ID
        scan_result: Scan result from scanner
    
    Returns:
        Job information
    """
    client = ServerClient(server_url, api_key)
    
    # Prepare upload payload
    payload = {
        'project_id': project_id,
        'checklist_id': checklist_id,
        'scan_result': scan_result,
        'source_path': scan_result.get('base_path', source_path),
        'agent_info': _collect_agent_info(),
    }
    
    # Upload
    job = client.upload_scan(payload)
    return job


def poll_results(server_url: str, api_key: str, job_id: int,
                source_path: str = "",
                poll_interval: int = 5, timeout: int = 600) -> Dict[str, Any]:
    """
    Poll for job results, fulfilling file content requests from the server.

    Args:
        server_url: Server URL
        api_key: API key
        job_id: Job ID
        source_path: Local source directory (needed to read file content)
        poll_interval: Seconds between polls
        timeout: Maximum wait time in seconds

    Returns:
        Job results
    """
    client = ServerClient(server_url, api_key)
    start_time = time.time()
    fulfilled: set = set()

    while True:
        elapsed = time.time() - start_time
        if elapsed > timeout:
            raise TimeoutError(f"Job {job_id} timed out after {timeout}s")

        # Fulfil any pending file content requests
        if source_path:
            try:
                requests = client.get_file_requests(job_id)
                for req in requests:
                    rel_path = req['file_path']
                    if rel_path in fulfilled:
                        continue
                    abs_path = os.path.join(source_path, rel_path)
                    if os.path.isfile(abs_path):
                        try:
                            with open(abs_path, 'r', encoding='utf-8', errors='replace') as fh:
                                content = fh.read()
                            client.upload_file_content(job_id, rel_path, content)
                            fulfilled.add(rel_path)
                        except Exception:
                            pass  # skip unreadable files silently
            except Exception:
                pass  # don't abort polling on file-request errors

        status = client.get_job_status(job_id)

        if status['status'] == 'completed':
            return client.get_job_results(job_id)
        elif status['status'] == 'failed':
            raise Exception(f"Job failed: {status.get('error_message', 'Unknown error')}")
        elif status['status'] in ['queued', 'running']:
            time.sleep(poll_interval)
        else:
            raise Exception(f"Unknown job status: {status['status']}")
