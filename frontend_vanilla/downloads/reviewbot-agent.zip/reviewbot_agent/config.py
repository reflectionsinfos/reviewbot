"""
Configuration management
"""
import os
import json
from pathlib import Path
from typing import Dict, Any, Optional

CONFIG_DIR = Path.home() / '.reviewbot'
CONFIG_FILE = CONFIG_DIR / 'config.json'


def get_config() -> Dict[str, Any]:
    """Get configuration from file"""
    if not CONFIG_FILE.exists():
        return {}
    
    try:
        with open(CONFIG_FILE, 'r') as f:
            return json.load(f)
    except (json.JSONDecodeError, IOError):
        return {}


def save_config(config: Dict[str, Any]) -> None:
    """Save configuration to file"""
    # Create directory if it doesn't exist
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    
    with open(CONFIG_FILE, 'w') as f:
        json.dump(config, f, indent=2)


def get_server_url() -> str:
    """Get server URL from config or environment"""
    config = get_config()
    return os.getenv('REVIEWBOT_SERVER', config.get('server', 'http://localhost:8000'))


def get_api_key() -> Optional[str]:
    """Get API key from config or environment"""
    config = get_config()
    return os.getenv('REVIEWBOT_API_KEY', config.get('api_key'))
