"""
ReviewBot CLI - Command Line Interface
"""
import click
import sys
from rich.console import Console
from rich.panel import Panel

from .scanner import scan_directory
from .uploader import upload_to_server, upload_all_files, poll_results
from .config import get_config, save_config

console = Console()


@click.group()
@click.version_option(version="0.1.0")
def main():
    """🤖 ReviewBot - Autonomous Code Review Agent
    
    Local agent that scans your codebase and communicates with ReviewBot server
    for AI-powered analysis.
    """
    pass


@main.command()
@click.option('--server', '-s', default='http://localhost:8000',
              help='ReviewBot server URL')
@click.option('--email', '-e', prompt='Email', help='Your ReviewBot account email')
@click.option('--password', '-p', prompt=True, hide_input=True, help='Your password')
def login(server, email, password):
    """Login to ReviewBot server (uses your email + password)"""
    import requests as _req
    try:
        resp = _req.post(
            f"{server.rstrip('/')}/api/auth/login",
            data={'username': email, 'password': password},
            timeout=15,
        )
        if resp.status_code == 401:
            console.print("[red]Login failed: invalid email or password.[/red]")
            sys.exit(1)
        resp.raise_for_status()
        token = resp.json().get('access_token')
        if not token:
            raise ValueError("Server did not return an access token.")
        save_config({'server': server, 'api_key': token, 'email': email})
        console.print(Panel(f"[green]Logged in as {email}[/green]"))
        console.print(f"Server: {server}")
    except _req.exceptions.ConnectionError:
        console.print(f"[red]Cannot reach server at {server}. Is ReviewBot running?[/red]")
        sys.exit(1)
    except Exception as e:
        console.print(f"[red]Login failed: {str(e)}[/red]")
        sys.exit(1)


@main.command()
@click.option('--project-id', '-p', required=True, type=int,
              help='Project ID')
@click.option('--checklist-id', '-c', required=True, type=int,
              help='Checklist ID')
@click.option('--source-path', '-S', required=True, type=click.Path(exists=True),
              help='Local path to source code')
@click.option('--output', '-o', type=click.Path(), default='review-report.md',
              help='Output file for report')
@click.option('--watch', '-w', is_flag=True,
              help='Watch for changes and re-run')
def review(project_id, checklist_id, source_path, output, watch):
    """🔍 Start autonomous code review"""
    console.print(Panel("[bold blue]🚀 Starting Autonomous Code Review[/bold blue]"))
    
    try:
        # Get configuration
        config = get_config()
        if not config:
            console.print("[red]✗ Not logged in. Run 'reviewbot login' first.[/red]")
            sys.exit(1)
        
        # Step 1: Scan local files
        console.print("\n[bold]📁 Step 1/4: Scanning local files...[/bold]")
        with console.status("[bold green]Scanning..."):
            scan_result = scan_directory(source_path)
        
        console.print(f"  ✓ Found {len(scan_result['files'])} code files")
        console.print(f"  ✓ Total size: {scan_result['total_size_mb']:.2f} MB")
        
        # Step 2: Upload to server
        console.print("\n[bold]📤 Step 2/4: Uploading to server...[/bold]")
        with console.status("[bold green]Uploading..."):
            job = upload_to_server(
                config['server'],
                config['api_key'],
                project_id,
                checklist_id,
                scan_result,
                source_path=source_path,
            )
        
        job_id = job['job_id']
        console.print(f"  ✓ Job ID: {job_id}")

        # Step 2b: Upload file contents so LLM/pattern analysis has access
        console.print("\n[bold]📂 Step 2b/4: Uploading file contents...[/bold]")
        from .uploader import ServerClient as _SC
        _client = _SC(config['server'], config['api_key'])

        def _progress(done, total):
            if done % 20 == 0 or done == total:
                console.print(f"  ↑ {done}/{total} files uploaded", end="\r")

        uploaded = upload_all_files(
            config['server'], config['api_key'], job_id,
            source_path, scan_result, progress_cb=_progress,
        )
        console.print(f"\n  ✓ {uploaded} files uploaded")

        # Start analysis now that files are in place
        _client.start_job(job_id)

        # Step 3: Poll for results
        console.print("\n[bold]⏳ Step 3/4: Analyzing code...[/bold]")
        results = poll_results(config['server'], config['api_key'], job_id, source_path=source_path)
        
        # Step 4: Display results
        console.print("\n[bold]📊 Step 4/4: Results[/bold]")
        display_results(results)
        
        # Save report
        if output:
            save_report(results, output)
            console.print(f"\n[green]✓ Report saved to: {output}[/green]")
        
        if watch:
            console.print("\n[yellow]Watching for changes... (Ctrl+C to stop)[/yellow]")
            # TODO: Implement file watching
        
    except Exception as e:
        console.print(f"\n[red]✗ Review failed: {str(e)}[/red]")
        if config.get('debug'):
            import traceback
            console.print(traceback.format_exc())
        sys.exit(1)


@main.command()
def status():
    """📊 Show agent status"""
    config = get_config()
    
    if not config:
        console.print("[yellow]Not logged in. Run 'reviewbot login' first.[/yellow]")
        return
    
    console.print(Panel("[bold]ReviewBot Agent Status[/bold]"))
    console.print(f"Server: {config.get('server', 'Not configured')}")
    console.print(f"Logged in: {'Yes' if config.get('api_key') else 'No'}")
    console.print(f"Debug mode: {'On' if config.get('debug') else 'Off'}")


@main.command()
def logout():
    """🚪 Logout from server"""
    save_config({})
    console.print("[green]✓ Logged out successfully[/green]")


def display_results(results):
    """Display review results in console"""
    from rich.table import Table
    
    summary = results.get('summary', {})
    
    # Summary table
    table = Table(title="Review Summary")
    table.add_column("Metric", style="cyan")
    table.add_column("Count", style="green")
    
    total = sum(summary.get(k, 0) for k in ('green', 'amber', 'red', 'skipped', 'na'))
    table.add_row("Total Items", str(total))
    table.add_row("🟢 Green", str(summary.get('green', 0)))
    table.add_row("🟡 Amber", str(summary.get('amber', 0)))
    table.add_row("🔴 Red", str(summary.get('red', 0)))
    table.add_row("Compliance Score", f"{results.get('compliance_score', 0):.1f}%")
    
    console.print(table)
    
    # Critical issues
    items = results.get('items', [])
    red_items = [i for i in items if i.get('rag_status') == 'red']
    
    if red_items:
        console.print("\n[bold red]Critical Issues (Red):[/bold red]")
        for item in red_items[:5]:  # Show first 5
            console.print(f"  • {item.get('item_code')}: {item.get('question')[:80]}")
        
        if len(red_items) > 5:
            console.print(f"  ... and {len(red_items) - 5} more")


def save_report(results, output_path):
    """Save report to file"""
    with open(output_path, 'w') as f:
        f.write(f"# ReviewBot Report\n\n")
        f.write(f"## Summary\n\n")
        s = results.get('summary', {})
        total = sum(s.get(k, 0) for k in ('green', 'amber', 'red', 'skipped', 'na'))
        f.write(f"- Total Items: {total}\n")
        f.write(f"- Green: {results.get('summary', {}).get('green', 0)}\n")
        f.write(f"- Amber: {results.get('summary', {}).get('amber', 0)}\n")
        f.write(f"- Red: {results.get('summary', {}).get('red', 0)}\n")
        f.write(f"- Compliance Score: {results.get('compliance_score', 0):.1f}%\n")


if __name__ == '__main__':
    main()
